import { useState, useEffect } from 'react';

export function useQuiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);

  useEffect(() => {
    // Load saved progress from localStorage
    const savedProgress = localStorage.getItem('quizProgress');
    if (savedProgress) {
      const progress = JSON.parse(savedProgress);
      setCurrentQuestion(progress.currentQuestion || 0);
      setSelectedAnswers(progress.selectedAnswers || []);
    }
  }, []);

  const selectAnswer = (questionIndex: number, value: number) => {
    const newAnswers = [...selectedAnswers];
    newAnswers[questionIndex] = value;
    setSelectedAnswers(newAnswers);
    
    // Save progress to localStorage
    localStorage.setItem('quizProgress', JSON.stringify({
      currentQuestion,
      selectedAnswers: newAnswers
    }));
  };

  const nextQuestion = () => {
    const newQuestion = currentQuestion + 1;
    setCurrentQuestion(newQuestion);
    
    // Save progress to localStorage
    localStorage.setItem('quizProgress', JSON.stringify({
      currentQuestion: newQuestion,
      selectedAnswers
    }));
  };

  const previousQuestion = () => {
    if (currentQuestion > 0) {
      const newQuestion = currentQuestion - 1;
      setCurrentQuestion(newQuestion);
      
      // Save progress to localStorage
      localStorage.setItem('quizProgress', JSON.stringify({
        currentQuestion: newQuestion,
        selectedAnswers
      }));
    }
  };

  const resetQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswers([]);
    localStorage.removeItem('quizProgress');
  };

  return {
    currentQuestion,
    selectedAnswers,
    setCurrentQuestion,
    selectAnswer,
    nextQuestion,
    previousQuestion,
    resetQuiz
  };
}
