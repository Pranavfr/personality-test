import { questions } from '@/data/questions';

export interface PersonalityScores {
  Mind: number; // I vs E
  Energy: number; // N vs S
  Nature: number; // F vs T
  Tactics: number; // P vs J
}

export interface PersonalityResult {
  code: string;
  scores: PersonalityScores;
}

export function calculatePersonalityType(answers: number[]): PersonalityResult {
  const scores = {
    Mind: 0,
    Energy: 0,
    Nature: 0,
    Tactics: 0
  };

  // Count responses for each dimension
  const dimensionCounts = {
    Mind: 0,
    Energy: 0,
    Nature: 0,
    Tactics: 0
  };

  questions.forEach((question, index) => {
    const answer = answers[index];
    if (answer === undefined) return;

    const dimension = question.dimension;
    dimensionCounts[dimension]++;

    // Convert 1-5 scale to scoring system
    // 1-2 = disagree, 3 = neutral, 4-5 = agree
    let score = 0;
    if (answer <= 2) {
      // Disagree - favor the opposite direction
      score = question.direction === 'I' || question.direction === 'N' || question.direction === 'F' || question.direction === 'P' ? 0 : 100;
    } else if (answer >= 4) {
      // Agree - favor the question's direction
      score = question.direction === 'I' || question.direction === 'N' || question.direction === 'F' || question.direction === 'P' ? 100 : 0;
    } else {
      // Neutral
      score = 50;
    }

    scores[dimension] += score;
  });

  // Calculate percentages
  const finalScores: PersonalityScores = {
    Mind: Math.round(scores.Mind / dimensionCounts.Mind),
    Energy: Math.round(scores.Energy / dimensionCounts.Energy),
    Nature: Math.round(scores.Nature / dimensionCounts.Nature),
    Tactics: Math.round(scores.Tactics / dimensionCounts.Tactics)
  };

  // Determine personality type
  const code = 
    (finalScores.Mind > 50 ? 'E' : 'I') +
    (finalScores.Energy > 50 ? 'N' : 'S') +
    (finalScores.Nature > 50 ? 'F' : 'T') +
    (finalScores.Tactics > 50 ? 'J' : 'P');

  return {
    code,
    scores: finalScores
  };
}
