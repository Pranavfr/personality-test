export interface Question {
  id: number;
  text: string;
  dimension: 'Mind' | 'Energy' | 'Nature' | 'Tactics';
  direction: 'I' | 'E' | 'N' | 'S' | 'T' | 'F' | 'J' | 'P';
}

export const questions: Question[] = [
  // Mind (Introversion vs Extraversion) - 14 questions
  { id: 1, text: "You regularly make new friends.", dimension: "Mind", direction: "E" },
  { id: 2, text: "You feel comfortable being the center of attention.", dimension: "Mind", direction: "E" },
  { id: 3, text: "You prefer to spend time alone rather than with others.", dimension: "Mind", direction: "I" },
  { id: 4, text: "You enjoy being around people most of the time.", dimension: "Mind", direction: "E" },
  { id: 5, text: "You find it easy to introduce yourself to new people.", dimension: "Mind", direction: "E" },
  { id: 6, text: "You prefer quiet, peaceful environments.", dimension: "Mind", direction: "I" },
  { id: 7, text: "You feel energized after spending time in social situations.", dimension: "Mind", direction: "E" },
  { id: 8, text: "You need time alone to recharge after social interactions.", dimension: "Mind", direction: "I" },
  { id: 9, text: "You speak up in group discussions.", dimension: "Mind", direction: "E" },
  { id: 10, text: "You prefer to think before speaking.", dimension: "Mind", direction: "I" },
  { id: 11, text: "You enjoy meeting new people at parties or events.", dimension: "Mind", direction: "E" },
  { id: 12, text: "You prefer intimate gatherings over large parties.", dimension: "Mind", direction: "I" },
  { id: 13, text: "You find it easy to start conversations with strangers.", dimension: "Mind", direction: "E" },
  { id: 14, text: "You feel drained after extensive social interaction.", dimension: "Mind", direction: "I" },

  // Energy (Intuition vs Sensing) - 13 questions
  { id: 15, text: "You focus on the big picture rather than details.", dimension: "Energy", direction: "N" },
  { id: 16, text: "You prefer practical, realistic solutions.", dimension: "Energy", direction: "S" },
  { id: 17, text: "You often think about future possibilities.", dimension: "Energy", direction: "N" },
  { id: 18, text: "You pay attention to facts and concrete information.", dimension: "Energy", direction: "S" },
  { id: 19, text: "You enjoy exploring abstract concepts and theories.", dimension: "Energy", direction: "N" },
  { id: 20, text: "You prefer to work with concrete, tangible things.", dimension: "Energy", direction: "S" },
  { id: 21, text: "You often see patterns and connections others miss.", dimension: "Energy", direction: "N" },
  { id: 22, text: "You focus on what is happening right now.", dimension: "Energy", direction: "S" },
  { id: 23, text: "You trust your hunches and intuition.", dimension: "Energy", direction: "N" },
  { id: 24, text: "You prefer step-by-step instructions.", dimension: "Energy", direction: "S" },
  { id: 25, text: "You enjoy brainstorming and generating new ideas.", dimension: "Energy", direction: "N" },
  { id: 26, text: "You prefer proven methods over new approaches.", dimension: "Energy", direction: "S" },
  { id: 27, text: "You often think about what could be rather than what is.", dimension: "Energy", direction: "N" },

  // Nature (Feeling vs Thinking) - 14 questions
  { id: 28, text: "You make decisions based on personal values.", dimension: "Nature", direction: "F" },
  { id: 29, text: "You prioritize logic over emotions in decision-making.", dimension: "Nature", direction: "T" },
  { id: 30, text: "You consider how decisions will affect other people.", dimension: "Nature", direction: "F" },
  { id: 31, text: "You believe objective analysis is more important than personal feelings.", dimension: "Nature", direction: "T" },
  { id: 32, text: "You are naturally empathetic and compassionate.", dimension: "Nature", direction: "F" },
  { id: 33, text: "You prefer to remain objective and impartial.", dimension: "Nature", direction: "T" },
  { id: 34, text: "You value harmony and cooperation.", dimension: "Nature", direction: "F" },
  { id: 35, text: "You believe in fair and equal treatment for everyone.", dimension: "Nature", direction: "T" },
  { id: 36, text: "You are sensitive to other people's emotions.", dimension: "Nature", direction: "F" },
  { id: 37, text: "You focus on finding logical solutions to problems.", dimension: "Nature", direction: "T" },
  { id: 38, text: "You prefer to avoid conflict and confrontation.", dimension: "Nature", direction: "F" },
  { id: 39, text: "You are comfortable with constructive criticism.", dimension: "Nature", direction: "T" },
  { id: 40, text: "You make decisions based on what feels right.", dimension: "Nature", direction: "F" },
  { id: 41, text: "You analyze situations objectively before acting.", dimension: "Nature", direction: "T" },

  // Tactics (Judging vs Prospecting) - 13 questions
  { id: 42, text: "You prefer to have a structured schedule.", dimension: "Tactics", direction: "J" },
  { id: 43, text: "You like to keep your options open.", dimension: "Tactics", direction: "P" },
  { id: 44, text: "You prefer to plan ahead rather than improvise.", dimension: "Tactics", direction: "J" },
  { id: 45, text: "You are comfortable with last-minute changes.", dimension: "Tactics", direction: "P" },
  { id: 46, text: "You like to complete tasks before moving on to new ones.", dimension: "Tactics", direction: "J" },
  { id: 47, text: "You enjoy working on multiple projects simultaneously.", dimension: "Tactics", direction: "P" },
  { id: 48, text: "You prefer closure and finality in decisions.", dimension: "Tactics", direction: "J" },
  { id: 49, text: "You are adaptable and flexible in your approach.", dimension: "Tactics", direction: "P" },
  { id: 50, text: "You like to have things settled and decided.", dimension: "Tactics", direction: "J" },
  { id: 51, text: "You work well under pressure and tight deadlines.", dimension: "Tactics", direction: "P" },
  { id: 52, text: "You prefer organized, systematic approaches.", dimension: "Tactics", direction: "J" },
  { id: 53, text: "You enjoy exploring different possibilities before deciding.", dimension: "Tactics", direction: "P" },
  { id: 54, text: "You feel more comfortable when things are planned out.", dimension: "Tactics", direction: "J" }
];
