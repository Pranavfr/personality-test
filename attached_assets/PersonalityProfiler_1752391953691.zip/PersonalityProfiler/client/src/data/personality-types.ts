export interface PersonalityType {
  code: string;
  title: string;
  description: string;
  emoji: string;
  strengths: string[];
  weaknesses: string[];
  famousPeople: { name: string; profession: string }[];
}

export const personalityTypes: PersonalityType[] = [
  {
    code: "INTJ",
    title: "The Architect",
    description: "Imaginative and strategic thinkers, with a plan for everything. They are independent, decisive, and highly value competence and achievement.",
    emoji: "🏗️",
    strengths: [
      "Strategic thinking and planning",
      "Independent and self-motivated",
      "High standards and quality focus",
      "Decisive and confident",
      "Innovative problem-solving"
    ],
    weaknesses: [
      "Can be overly critical",
      "May struggle with emotions",
      "Tendency to be impatient",
      "Can appear arrogant",
      "May overlook details"
    ],
    famousPeople: [
      { name: "Elon Musk", profession: "Entrepreneur" },
      { name: "Isaac Newton", profession: "Physicist" },
      { name: "Nikola Tesla", profession: "Inventor" },
      { name: "Friedrich Nietzsche", profession: "Philosopher" }
    ]
  },
  {
    code: "INTP",
    title: "The Thinker",
    description: "Innovative inventors with an unquenchable thirst for knowledge. They are logical, analytical, and value intellectual pursuits above all else.",
    emoji: "🧠",
    strengths: [
      "Logical and analytical thinking",
      "Creative problem-solving",
      "Independent and objective",
      "Intellectually curious",
      "Flexible and adaptable"
    ],
    weaknesses: [
      "Can be insensitive to others",
      "May procrastinate on routine tasks",
      "Struggle with emotional expression",
      "Can be overly critical",
      "May lack follow-through"
    ],
    famousPeople: [
      { name: "Albert Einstein", profession: "Physicist" },
      { name: "Marie Curie", profession: "Scientist" },
      { name: "Charles Darwin", profession: "Naturalist" },
      { name: "Socrates", profession: "Philosopher" }
    ]
  },
  {
    code: "ENTJ",
    title: "The Commander",
    description: "Bold, imaginative and strong-willed leaders, always finding a way – or making one. They are natural leaders who thrive on organizing and directing others.",
    emoji: "👑",
    strengths: [
      "Natural leadership abilities",
      "Strategic and visionary thinking",
      "Decisive and confident",
      "Excellent at organizing",
      "Inspiring and motivating"
    ],
    weaknesses: [
      "Can be domineering",
      "May be insensitive to others",
      "Impatient with inefficiency",
      "Can be overly competitive",
      "May neglect personal relationships"
    ],
    famousPeople: [
      { name: "Steve Jobs", profession: "Entrepreneur" },
      { name: "Napoleon Bonaparte", profession: "Military Leader" },
      { name: "Margaret Thatcher", profession: "Politician" },
      { name: "Franklin D. Roosevelt", profession: "President" }
    ]
  },
  {
    code: "ENTP",
    title: "The Debater",
    description: "Smart and curious thinkers who cannot resist an intellectual challenge. They are innovative, versatile, and excel at generating ideas and possibilities.",
    emoji: "💡",
    strengths: [
      "Innovative and creative",
      "Excellent at generating ideas",
      "Charismatic and inspiring",
      "Intellectually curious",
      "Adaptable and versatile"
    ],
    weaknesses: [
      "Can be argumentative",
      "May struggle with routine tasks",
      "Can be insensitive to others",
      "May lack follow-through",
      "Can be overly optimistic"
    ],
    famousPeople: [
      { name: "Leonardo da Vinci", profession: "Artist/Inventor" },
      { name: "Walt Disney", profession: "Entrepreneur" },
      { name: "Mark Twain", profession: "Author" },
      { name: "Richard Feynman", profession: "Physicist" }
    ]
  },
  {
    code: "INFJ",
    title: "The Advocate",
    description: "Quiet and mystical, yet very inspiring and tireless idealists. They are creative, insightful, and driven by their values and vision for humanity.",
    emoji: "🌟",
    strengths: [
      "Insightful and intuitive",
      "Idealistic and principled",
      "Creative and imaginative",
      "Empathetic and compassionate",
      "Determined and focused"
    ],
    weaknesses: [
      "Can be overly sensitive",
      "May be too idealistic",
      "Tendency to burn out",
      "Can be rigid in beliefs",
      "May struggle with criticism"
    ],
    famousPeople: [
      { name: "Martin Luther King Jr.", profession: "Civil Rights Leader" },
      { name: "Gandhi", profession: "Activist" },
      { name: "Nelson Mandela", profession: "Political Leader" },
      { name: "Mother Teresa", profession: "Humanitarian" }
    ]
  },
  {
    code: "INFP",
    title: "The Mediator",
    description: "Poetic, kind and altruistic people, always eager to help a good cause. They are idealistic, loyal, and driven by their values and desire to help others.",
    emoji: "🌸",
    strengths: [
      "Empathetic and understanding",
      "Creative and imaginative",
      "Passionate about personal values",
      "Dedicated and hardworking",
      "Flexible and open-minded"
    ],
    weaknesses: [
      "Can be overly critical of themselves",
      "May struggle with practical matters",
      "Tendency to avoid difficult situations",
      "Can be too sensitive to criticism",
      "May procrastinate on unpleasant tasks"
    ],
    famousPeople: [
      { name: "Johnny Depp", profession: "Actor" },
      { name: "J.K. Rowling", profession: "Author" },
      { name: "Kurt Cobain", profession: "Musician" },
      { name: "Princess Diana", profession: "Humanitarian" }
    ]
  },
  {
    code: "ENFJ",
    title: "The Protagonist",
    description: "Charismatic and inspiring leaders, able to mesmerize their listeners. They are passionate, altruistic, and natural-born leaders focused on helping others.",
    emoji: "🌅",
    strengths: [
      "Inspiring and motivating",
      "Excellent communication skills",
      "Empathetic and understanding",
      "Natural leadership abilities",
      "Passionate and enthusiastic"
    ],
    weaknesses: [
      "Can be overly idealistic",
      "May struggle with criticism",
      "Tendency to be too selfless",
      "Can be manipulative",
      "May neglect own needs"
    ],
    famousPeople: [
      { name: "Oprah Winfrey", profession: "Media Mogul" },
      { name: "John F. Kennedy", profession: "President" },
      { name: "Maya Angelou", profession: "Author" },
      { name: "Martin Luther King Jr.", profession: "Civil Rights Leader" }
    ]
  },
  {
    code: "ENFP",
    title: "The Campaigner",
    description: "Enthusiastic, creative and sociable free spirits, who can always find a reason to smile. They are passionate, energetic, and excellent at inspiring others.",
    emoji: "🎨",
    strengths: [
      "Enthusiastic and energetic",
      "Creative and imaginative",
      "Excellent people skills",
      "Flexible and adaptable",
      "Inspiring and motivating"
    ],
    weaknesses: [
      "Can be overly optimistic",
      "May struggle with routine tasks",
      "Can be easily distracted",
      "May lack follow-through",
      "Can be overly emotional"
    ],
    famousPeople: [
      { name: "Robin Williams", profession: "Actor/Comedian" },
      { name: "Walt Disney", profession: "Entrepreneur" },
      { name: "Ellen DeGeneres", profession: "TV Host" },
      { name: "Will Smith", profession: "Actor" }
    ]
  },
  {
    code: "ISTJ",
    title: "The Logistician",
    description: "Practical and fact-minded, reliable and responsible. They are methodical, detail-oriented, and value tradition and stability.",
    emoji: "📋",
    strengths: [
      "Reliable and responsible",
      "Detail-oriented and thorough",
      "Logical and practical",
      "Strong sense of duty",
      "Excellent at planning"
    ],
    weaknesses: [
      "Can be inflexible",
      "May resist change",
      "Can be overly critical",
      "May struggle with emotions",
      "Can be too serious"
    ],
    famousPeople: [
      { name: "George Washington", profession: "President" },
      { name: "Warren Buffett", profession: "Investor" },
      { name: "Queen Elizabeth II", profession: "Monarch" },
      { name: "Angela Merkel", profession: "Politician" }
    ]
  },
  {
    code: "ISFJ",
    title: "The Protector",
    description: "Very dedicated and warm protectors, always ready to defend their loved ones. They are nurturing, supportive, and deeply committed to helping others.",
    emoji: "🛡️",
    strengths: [
      "Loyal and dedicated",
      "Supportive and nurturing",
      "Detail-oriented and thorough",
      "Empathetic and caring",
      "Reliable and responsible"
    ],
    weaknesses: [
      "Can be too selfless",
      "May struggle with change",
      "Can be overly sensitive",
      "May avoid confrontation",
      "Can be taken advantage of"
    ],
    famousPeople: [
      { name: "Mother Teresa", profession: "Humanitarian" },
      { name: "Rosa Parks", profession: "Civil Rights Activist" },
      { name: "Kate Middleton", profession: "Royalty" },
      { name: "Jimmy Carter", profession: "President" }
    ]
  },
  {
    code: "ESTJ",
    title: "The Executive",
    description: "Excellent administrators, unsurpassed at managing things – or people. They are organized, decisive, and natural leaders who value efficiency and results.",
    emoji: "💼",
    strengths: [
      "Excellent organizational skills",
      "Natural leadership abilities",
      "Decisive and efficient",
      "Strong sense of responsibility",
      "Goal-oriented and results-focused"
    ],
    weaknesses: [
      "Can be inflexible",
      "May be insensitive to others",
      "Can be overly controlling",
      "May struggle with emotions",
      "Can be impatient with inefficiency"
    ],
    famousPeople: [
      { name: "Hillary Clinton", profession: "Politician" },
      { name: "John D. Rockefeller", profession: "Industrialist" },
      { name: "Judge Judy", profession: "TV Judge" },
      { name: "Martha Stewart", profession: "Businesswoman" }
    ]
  },
  {
    code: "ESFJ",
    title: "The Consul",
    description: "Extraordinarily caring, social and popular people, always eager to help. They are warm, supportive, and naturally attuned to others' needs.",
    emoji: "🤝",
    strengths: [
      "Warm and supportive",
      "Excellent people skills",
      "Loyal and dedicated",
      "Organized and responsible",
      "Empathetic and caring"
    ],
    weaknesses: [
      "Can be overly people-pleasing",
      "May struggle with criticism",
      "Can be inflexible",
      "May neglect own needs",
      "Can be overly sensitive"
    ],
    famousPeople: [
      { name: "Taylor Swift", profession: "Singer" },
      { name: "Hugh Jackman", profession: "Actor" },
      { name: "Sally Field", profession: "Actress" },
      { name: "Danny Glover", profession: "Actor" }
    ]
  },
  {
    code: "ISTP",
    title: "The Virtuoso",
    description: "Bold and practical experimenters, masters of all kinds of tools. They are independent, logical, and excel at understanding how things work.",
    emoji: "🔧",
    strengths: [
      "Practical and hands-on",
      "Independent and self-reliant",
      "Logical and analytical",
      "Calm under pressure",
      "Excellent problem-solvers"
    ],
    weaknesses: [
      "Can be insensitive to others",
      "May struggle with emotions",
      "Can be unpredictable",
      "May be too independent",
      "Can be stubborn"
    ],
    famousPeople: [
      { name: "Clint Eastwood", profession: "Actor/Director" },
      { name: "Bruce Lee", profession: "Martial Artist" },
      { name: "Steve Jobs", profession: "Entrepreneur" },
      { name: "Michael Jordan", profession: "Athlete" }
    ]
  },
  {
    code: "ISFP",
    title: "The Adventurer",
    description: "Flexible and charming artists, always ready to explore new possibilities. They are sensitive, creative, and driven by their values and aesthetics.",
    emoji: "🎭",
    strengths: [
      "Creative and artistic",
      "Flexible and adaptable",
      "Sensitive and empathetic",
      "Values-driven and authentic",
      "Open-minded and curious"
    ],
    weaknesses: [
      "Can be overly sensitive",
      "May struggle with long-term planning",
      "Can be unpredictable",
      "May avoid confrontation",
      "Can be too idealistic"
    ],
    famousPeople: [
      { name: "Bob Dylan", profession: "Musician" },
      { name: "Frida Kahlo", profession: "Artist" },
      { name: "Audrey Hepburn", profession: "Actress" },
      { name: "Mozart", profession: "Composer" }
    ]
  },
  {
    code: "ESTP",
    title: "The Entrepreneur",
    description: "Smart, energetic and very perceptive people, who truly enjoy living on the edge. They are spontaneous, pragmatic, and excel at adapting to new situations.",
    emoji: "🚀",
    strengths: [
      "Energetic and enthusiastic",
      "Practical and realistic",
      "Spontaneous and flexible",
      "Excellent in crisis situations",
      "Charismatic and persuasive"
    ],
    weaknesses: [
      "Can be impulsive",
      "May struggle with long-term planning",
      "Can be insensitive to others",
      "May be too focused on the present",
      "Can be easily bored"
    ],
    famousPeople: [
      { name: "Donald Trump", profession: "Businessman/President" },
      { name: "Madonna", profession: "Singer" },
      { name: "Winston Churchill", profession: "Politician" },
      { name: "Ernest Hemingway", profession: "Author" }
    ]
  },
  {
    code: "ESFP",
    title: "The Entertainer",
    description: "Spontaneous, energetic and enthusiastic people – life is never boring around them. They are warm, friendly, and love to be the center of attention.",
    emoji: "🎪",
    strengths: [
      "Enthusiastic and energetic",
      "Warm and friendly",
      "Spontaneous and fun-loving",
      "Excellent people skills",
      "Practical and realistic"
    ],
    weaknesses: [
      "Can be easily distracted",
      "May struggle with long-term planning",
      "Can be overly sensitive",
      "May avoid difficult conversations",
      "Can be impulsive"
    ],
    famousPeople: [
      { name: "Marilyn Monroe", profession: "Actress" },
      { name: "Elvis Presley", profession: "Singer" },
      { name: "Will Smith", profession: "Actor" },
      { name: "Jamie Foxx", profession: "Actor/Singer" }
    ]
  }
];
